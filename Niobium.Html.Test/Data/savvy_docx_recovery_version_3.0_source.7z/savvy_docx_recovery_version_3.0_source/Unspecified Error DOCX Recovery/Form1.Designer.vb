﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.picWordFixLink = New System.Windows.Forms.PictureBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.menuMain = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.OfficeUpdatesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HotfixForWord2007ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HotfixForWord2010ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DownloadAndInstallTheLatestOfficeServicePackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlternativesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FreeAlternativesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.PreviousVersionFileRecovererForWindowsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShadowExplorerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PreviousVersionFileRecovererToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnsavedOfficeFileRecoveryStepsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StepsToRecoverOfficeFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StepsToRecoverAWordFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StepsToRecoveringAnOpenOfficeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FreewareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.S2ServicesCorruptFileRecoveryFreewareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetDatasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SilverCodersDocToTextToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MicrosoftsFreeOffVisMightHelpWithDOCCorruptionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MrFixitThisAppletWillFixEndTagNotMatchingErrorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FreeServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TryFreeOnlineServiceUseCouponS2SERVICESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.S2ServicesFreeServiceCurrentlyUnavailableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadToZohoOfficeManyUnspecifiedAndAlsoMaybeEndTagErrrorsWillLoadInZohoWriterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubmitToAMicrosoftUserGroupForAWOrdMVPOrExperToFixToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommercialAlternativesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.CImawareSoftwareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem17 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OfficeFixToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TryOurManual22RepairToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem16 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecoverButton = New System.Windows.Forms.Button()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.MyApplicationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWordFixLink, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.menuMain.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MyApplicationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(17, 38)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(298, 20)
        Me.TextBox1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(323, 35)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(59, 22)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Browse"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(142, 62)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 125
        Me.Label3.Text = "File Path"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(369, 239)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 26)
        Me.Label5.TabIndex = 136
        Me.Label5.Text = "Install Office" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Service Packs!"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(34, 351)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 26)
        Me.Label6.TabIndex = 132
        Me.Label6.Text = "Upload to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Zoho Office"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(130, 351)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 26)
        Me.Label2.TabIndex = 133
        Me.Label2.Text = "Submit for Free " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Word MVP Repair"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(243, 351)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 26)
        Me.Label1.TabIndex = 131
        Me.Label1.Text = "Submit for $22" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Manual Repair"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(114, 239)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 26)
        Me.Label7.TabIndex = 136
        Me.Label7.Text = "Hotfix for" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Word 2010"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.White
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox4.Image = Global.SavvyDOCXRecovery.My.Resources.Resources.hotfix_available2
        Me.PictureBox4.Location = New System.Drawing.Point(109, 163)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Padding = New System.Windows.Forms.Padding(3)
        Me.PictureBox4.Size = New System.Drawing.Size(67, 65)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 137
        Me.PictureBox4.TabStop = False
        Me.PictureBox4.Tag = "Open and Extract Data"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Image = Global.SavvyDOCXRecovery.My.Resources.Resources.office_symbol_clr_56x56
        Me.PictureBox1.Location = New System.Drawing.Point(373, 163)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Padding = New System.Windows.Forms.Padding(3)
        Me.PictureBox1.Size = New System.Drawing.Size(67, 65)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 137
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Tag = "Open and Extract Data"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.White
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox3.Image = Global.SavvyDOCXRecovery.My.Resources.Resources.zl
        Me.PictureBox3.Location = New System.Drawing.Point(31, 276)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Padding = New System.Windows.Forms.Padding(3)
        Me.PictureBox3.Size = New System.Drawing.Size(67, 65)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 134
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Tag = "Open and Extract Data"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Image = Global.SavvyDOCXRecovery.My.Resources.Resources.mvp
        Me.PictureBox2.Location = New System.Drawing.Point(142, 276)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Padding = New System.Windows.Forms.Padding(3)
        Me.PictureBox2.Size = New System.Drawing.Size(67, 65)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2.TabIndex = 135
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Tag = "Open and Extract Data"
        '
        'picWordFixLink
        '
        Me.picWordFixLink.BackColor = System.Drawing.Color.White
        Me.picWordFixLink.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picWordFixLink.Image = CType(resources.GetObject("picWordFixLink.Image"), System.Drawing.Image)
        Me.picWordFixLink.Location = New System.Drawing.Point(247, 276)
        Me.picWordFixLink.Name = "picWordFixLink"
        Me.picWordFixLink.Padding = New System.Windows.Forms.Padding(3)
        Me.picWordFixLink.Size = New System.Drawing.Size(67, 65)
        Me.picWordFixLink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picWordFixLink.TabIndex = 130
        Me.picWordFixLink.TabStop = False
        Me.picWordFixLink.Tag = "Open and Extract Data"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(17, 78)
        Me.RichTextBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(428, 44)
        Me.RichTextBox1.TabIndex = 139
        Me.RichTextBox1.Text = ""
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(52, 128)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(360, 26)
        Me.Label8.TabIndex = 140
        Me.Label8.Text = "For unspecified errors files only, the above XML was excised from corrupt" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the do" & _
    "cument.xml subfile. Please examine it closely to recreate the content."
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.White
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(21, 163)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Padding = New System.Windows.Forms.Padding(3)
        Me.PictureBox5.Size = New System.Drawing.Size(67, 65)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 141
        Me.PictureBox5.TabStop = False
        Me.PictureBox5.Tag = "Open and Extract Data"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(26, 239)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 26)
        Me.Label9.TabIndex = 142
        Me.Label9.Text = "Hotfix for" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Word 2007"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(191, 239)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 26)
        Me.Label4.TabIndex = 136
        Me.Label4.Text = "Mr Fixit Math" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Tag Order Fixer"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.White
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(197, 163)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Padding = New System.Windows.Forms.Padding(3)
        Me.PictureBox6.Size = New System.Drawing.Size(67, 65)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 137
        Me.PictureBox6.TabStop = False
        Me.PictureBox6.Tag = "Open and Extract Data"
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.White
        Me.PictureBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(353, 276)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Padding = New System.Windows.Forms.Padding(3)
        Me.PictureBox7.Size = New System.Drawing.Size(67, 65)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox7.TabIndex = 143
        Me.PictureBox7.TabStop = False
        Me.PictureBox7.Tag = "Open and Extract Data"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(337, 351)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(102, 26)
        Me.Label10.TabIndex = 144
        Me.Label10.Text = "Other DOCX" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Recover Resources"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'menuMain
        '
        Me.menuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem9, Me.ToolStripMenuItem11, Me.OfficeUpdatesToolStripMenuItem, Me.AlternativesToolStripMenuItem, Me.ToolStripMenuItem5})
        Me.menuMain.Location = New System.Drawing.Point(0, 0)
        Me.menuMain.Name = "menuMain"
        Me.menuMain.Padding = New System.Windows.Forms.Padding(4, 1, 0, 1)
        Me.menuMain.Size = New System.Drawing.Size(461, 24)
        Me.menuMain.TabIndex = 145
        Me.menuMain.Text = "menuMain"
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem10, Me.ExitToolStripMenuItem1})
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(36, 22)
        Me.ToolStripMenuItem9.Text = "File"
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(104, 22)
        Me.ToolStripMenuItem10.Text = "Open"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(104, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem12, Me.ToolStripSeparator5, Me.ToolStripMenuItem15, Me.ToolStripSeparator6})
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(63, 22)
        Me.ToolStripMenuItem11.Text = "Recover"
        '
        'ToolStripMenuItem12
        '
        Me.ToolStripMenuItem12.Name = "ToolStripMenuItem12"
        Me.ToolStripMenuItem12.Size = New System.Drawing.Size(241, 22)
        Me.ToolStripMenuItem12.Text = "Text and Formatting Recovery"
        Me.ToolStripMenuItem12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(238, 6)
        '
        'ToolStripMenuItem15
        '
        Me.ToolStripMenuItem15.Name = "ToolStripMenuItem15"
        Me.ToolStripMenuItem15.Size = New System.Drawing.Size(241, 22)
        Me.ToolStripMenuItem15.Text = "Try Salvaging Just Text"
        Me.ToolStripMenuItem15.ToolTipText = "Alternative repair approach combined with Document.xml transplantation"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(238, 6)
        '
        'OfficeUpdatesToolStripMenuItem
        '
        Me.OfficeUpdatesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HotfixForWord2007ToolStripMenuItem, Me.HotfixForWord2010ToolStripMenuItem, Me.DownloadAndInstallTheLatestOfficeServicePackToolStripMenuItem})
        Me.OfficeUpdatesToolStripMenuItem.Name = "OfficeUpdatesToolStripMenuItem"
        Me.OfficeUpdatesToolStripMenuItem.Size = New System.Drawing.Size(100, 22)
        Me.OfficeUpdatesToolStripMenuItem.Text = "Office Updates"
        '
        'HotfixForWord2007ToolStripMenuItem
        '
        Me.HotfixForWord2007ToolStripMenuItem.Name = "HotfixForWord2007ToolStripMenuItem"
        Me.HotfixForWord2007ToolStripMenuItem.Size = New System.Drawing.Size(348, 22)
        Me.HotfixForWord2007ToolStripMenuItem.Text = "Hotfix for Word 2007"
        '
        'HotfixForWord2010ToolStripMenuItem
        '
        Me.HotfixForWord2010ToolStripMenuItem.Name = "HotfixForWord2010ToolStripMenuItem"
        Me.HotfixForWord2010ToolStripMenuItem.Size = New System.Drawing.Size(348, 22)
        Me.HotfixForWord2010ToolStripMenuItem.Text = "Hotfix for Word 2010"
        '
        'DownloadAndInstallTheLatestOfficeServicePackToolStripMenuItem
        '
        Me.DownloadAndInstallTheLatestOfficeServicePackToolStripMenuItem.Name = "DownloadAndInstallTheLatestOfficeServicePackToolStripMenuItem"
        Me.DownloadAndInstallTheLatestOfficeServicePackToolStripMenuItem.Size = New System.Drawing.Size(348, 22)
        Me.DownloadAndInstallTheLatestOfficeServicePackToolStripMenuItem.Text = "Download and install the latest Office service pack"
        '
        'AlternativesToolStripMenuItem
        '
        Me.AlternativesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FreeAlternativesToolStripMenuItem, Me.ToolStripSeparator7, Me.PreviousVersionFileRecovererForWindowsToolStripMenuItem, Me.StepsToRecoverOfficeFilesToolStripMenuItem, Me.FreewareToolStripMenuItem, Me.FreeServicesToolStripMenuItem, Me.CommercialAlternativesToolStripMenuItem, Me.ToolStripSeparator8, Me.CImawareSoftwareToolStripMenuItem, Me.TryOurManual22RepairToolStripMenuItem})
        Me.AlternativesToolStripMenuItem.Name = "AlternativesToolStripMenuItem"
        Me.AlternativesToolStripMenuItem.Size = New System.Drawing.Size(83, 22)
        Me.AlternativesToolStripMenuItem.Text = "Alternatives"
        '
        'FreeAlternativesToolStripMenuItem
        '
        Me.FreeAlternativesToolStripMenuItem.AccessibleRole = System.Windows.Forms.AccessibleRole.ColumnHeader
        Me.FreeAlternativesToolStripMenuItem.Name = "FreeAlternativesToolStripMenuItem"
        Me.FreeAlternativesToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.FreeAlternativesToolStripMenuItem.Text = "Free Alternatives"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(280, 6)
        '
        'PreviousVersionFileRecovererForWindowsToolStripMenuItem
        '
        Me.PreviousVersionFileRecovererForWindowsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShadowExplorerToolStripMenuItem, Me.PreviousVersionFileRecovererToolStripMenuItem, Me.UnsavedOfficeFileRecoveryStepsToolStripMenuItem})
        Me.PreviousVersionFileRecovererForWindowsToolStripMenuItem.Name = "PreviousVersionFileRecovererForWindowsToolStripMenuItem"
        Me.PreviousVersionFileRecovererForWindowsToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.PreviousVersionFileRecovererForWindowsToolStripMenuItem.Text = "Recover Previous Version"
        '
        'ShadowExplorerToolStripMenuItem
        '
        Me.ShadowExplorerToolStripMenuItem.Name = "ShadowExplorerToolStripMenuItem"
        Me.ShadowExplorerToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.ShadowExplorerToolStripMenuItem.Text = "Shadow Explorer"
        '
        'PreviousVersionFileRecovererToolStripMenuItem
        '
        Me.PreviousVersionFileRecovererToolStripMenuItem.Name = "PreviousVersionFileRecovererToolStripMenuItem"
        Me.PreviousVersionFileRecovererToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.PreviousVersionFileRecovererToolStripMenuItem.Text = "Previous Version File Recoverer"
        '
        'UnsavedOfficeFileRecoveryStepsToolStripMenuItem
        '
        Me.UnsavedOfficeFileRecoveryStepsToolStripMenuItem.Name = "UnsavedOfficeFileRecoveryStepsToolStripMenuItem"
        Me.UnsavedOfficeFileRecoveryStepsToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.UnsavedOfficeFileRecoveryStepsToolStripMenuItem.Text = "Unsaved Office File Recovery Steps"
        '
        'StepsToRecoverOfficeFilesToolStripMenuItem
        '
        Me.StepsToRecoverOfficeFilesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StepsToRecoverAWordFileToolStripMenuItem, Me.StepsToRecoveringAnOpenOfficeFileToolStripMenuItem})
        Me.StepsToRecoverOfficeFilesToolStripMenuItem.Name = "StepsToRecoverOfficeFilesToolStripMenuItem"
        Me.StepsToRecoverOfficeFilesToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.StepsToRecoverOfficeFilesToolStripMenuItem.Text = "Advice on How to Recover Office Files"
        '
        'StepsToRecoverAWordFileToolStripMenuItem
        '
        Me.StepsToRecoverAWordFileToolStripMenuItem.Name = "StepsToRecoverAWordFileToolStripMenuItem"
        Me.StepsToRecoverAWordFileToolStripMenuItem.Size = New System.Drawing.Size(293, 22)
        Me.StepsToRecoverAWordFileToolStripMenuItem.Text = "Steps to Recovering a Word File"
        '
        'StepsToRecoveringAnOpenOfficeFileToolStripMenuItem
        '
        Me.StepsToRecoveringAnOpenOfficeFileToolStripMenuItem.Name = "StepsToRecoveringAnOpenOfficeFileToolStripMenuItem"
        Me.StepsToRecoveringAnOpenOfficeFileToolStripMenuItem.Size = New System.Drawing.Size(293, 22)
        Me.StepsToRecoveringAnOpenOfficeFileToolStripMenuItem.Text = "Steps to Recovering an Open Office File"
        '
        'FreewareToolStripMenuItem
        '
        Me.FreewareToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.S2ServicesCorruptFileRecoveryFreewareToolStripMenuItem, Me.GetDatasToolStripMenuItem, Me.SilverCodersDocToTextToolStripMenuItem, Me.MicrosoftsFreeOffVisMightHelpWithDOCCorruptionToolStripMenuItem, Me.MrFixitThisAppletWillFixEndTagNotMatchingErrorsToolStripMenuItem})
        Me.FreewareToolStripMenuItem.Name = "FreewareToolStripMenuItem"
        Me.FreewareToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.FreewareToolStripMenuItem.Text = "Freeware"
        '
        'S2ServicesCorruptFileRecoveryFreewareToolStripMenuItem
        '
        Me.S2ServicesCorruptFileRecoveryFreewareToolStripMenuItem.Name = "S2ServicesCorruptFileRecoveryFreewareToolStripMenuItem"
        Me.S2ServicesCorruptFileRecoveryFreewareToolStripMenuItem.Size = New System.Drawing.Size(446, 22)
        Me.S2ServicesCorruptFileRecoveryFreewareToolStripMenuItem.Text = "S2 Services Corrupt File Recovery Freeware - my earlier software"
        '
        'GetDatasToolStripMenuItem
        '
        Me.GetDatasToolStripMenuItem.Name = "GetDatasToolStripMenuItem"
        Me.GetDatasToolStripMenuItem.Size = New System.Drawing.Size(446, 22)
        Me.GetDatasToolStripMenuItem.Text = "GetData's Repair My Word - for doc not docx files"
        '
        'SilverCodersDocToTextToolStripMenuItem
        '
        Me.SilverCodersDocToTextToolStripMenuItem.Name = "SilverCodersDocToTextToolStripMenuItem"
        Me.SilverCodersDocToTextToolStripMenuItem.Size = New System.Drawing.Size(446, 22)
        Me.SilverCodersDocToTextToolStripMenuItem.Text = "SilverCoder's DocToText - an excellent command line text extractor"
        '
        'MicrosoftsFreeOffVisMightHelpWithDOCCorruptionToolStripMenuItem
        '
        Me.MicrosoftsFreeOffVisMightHelpWithDOCCorruptionToolStripMenuItem.Name = "MicrosoftsFreeOffVisMightHelpWithDOCCorruptionToolStripMenuItem"
        Me.MicrosoftsFreeOffVisMightHelpWithDOCCorruptionToolStripMenuItem.Size = New System.Drawing.Size(446, 22)
        Me.MicrosoftsFreeOffVisMightHelpWithDOCCorruptionToolStripMenuItem.Text = "Microsoft's Free OffVis - might help with DOC corruption"
        '
        'MrFixitThisAppletWillFixEndTagNotMatchingErrorsToolStripMenuItem
        '
        Me.MrFixitThisAppletWillFixEndTagNotMatchingErrorsToolStripMenuItem.Name = "MrFixitThisAppletWillFixEndTagNotMatchingErrorsToolStripMenuItem"
        Me.MrFixitThisAppletWillFixEndTagNotMatchingErrorsToolStripMenuItem.Size = New System.Drawing.Size(446, 22)
        Me.MrFixitThisAppletWillFixEndTagNotMatchingErrorsToolStripMenuItem.Text = "Mr. Fixit - this applet will fix end tag not matching errors"
        '
        'FreeServicesToolStripMenuItem
        '
        Me.FreeServicesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TryFreeOnlineServiceUseCouponS2SERVICESToolStripMenuItem, Me.S2ServicesFreeServiceCurrentlyUnavailableToolStripMenuItem, Me.UploadToZohoOfficeManyUnspecifiedAndAlsoMaybeEndTagErrrorsWillLoadInZohoWriterToolStripMenuItem, Me.SubmitToAMicrosoftUserGroupForAWOrdMVPOrExperToFixToolStripMenuItem})
        Me.FreeServicesToolStripMenuItem.Name = "FreeServicesToolStripMenuItem"
        Me.FreeServicesToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.FreeServicesToolStripMenuItem.Text = "Free Services"
        '
        'TryFreeOnlineServiceUseCouponS2SERVICESToolStripMenuItem
        '
        Me.TryFreeOnlineServiceUseCouponS2SERVICESToolStripMenuItem.Name = "TryFreeOnlineServiceUseCouponS2SERVICESToolStripMenuItem"
        Me.TryFreeOnlineServiceUseCouponS2SERVICESToolStripMenuItem.Size = New System.Drawing.Size(575, 22)
        Me.TryFreeOnlineServiceUseCouponS2SERVICESToolStripMenuItem.Text = "Recoveronix' Online File Repair - for free service try coupon code ""S2SERVICES"""
        '
        'S2ServicesFreeServiceCurrentlyUnavailableToolStripMenuItem
        '
        Me.S2ServicesFreeServiceCurrentlyUnavailableToolStripMenuItem.Name = "S2ServicesFreeServiceCurrentlyUnavailableToolStripMenuItem"
        Me.S2ServicesFreeServiceCurrentlyUnavailableToolStripMenuItem.Size = New System.Drawing.Size(575, 22)
        Me.S2ServicesFreeServiceCurrentlyUnavailableToolStripMenuItem.Text = "MunSoft's Online Repair Service - make a Tweet, Facebook or blog post for free se" & _
    "rvice"
        '
        'UploadToZohoOfficeManyUnspecifiedAndAlsoMaybeEndTagErrrorsWillLoadInZohoWriterToolStripMenuItem
        '
        Me.UploadToZohoOfficeManyUnspecifiedAndAlsoMaybeEndTagErrrorsWillLoadInZohoWriterToolStripMenuItem.Name = "UploadToZohoOfficeManyUnspecifiedAndAlsoMaybeEndTagErrrorsWillLoadInZohoWriterToo" & _
    "lStripMenuItem"
        Me.UploadToZohoOfficeManyUnspecifiedAndAlsoMaybeEndTagErrrorsWillLoadInZohoWriterToolStripMenuItem.Size = New System.Drawing.Size(575, 22)
        Me.UploadToZohoOfficeManyUnspecifiedAndAlsoMaybeEndTagErrrorsWillLoadInZohoWriterToolStripMenuItem.Text = "Upload to Zoho Office - most ""Unspecified Error"" corrupt Word files will open in " & _
    "Zoho writer"
        '
        'SubmitToAMicrosoftUserGroupForAWOrdMVPOrExperToFixToolStripMenuItem
        '
        Me.SubmitToAMicrosoftUserGroupForAWOrdMVPOrExperToFixToolStripMenuItem.Name = "SubmitToAMicrosoftUserGroupForAWOrdMVPOrExperToFixToolStripMenuItem"
        Me.SubmitToAMicrosoftUserGroupForAWOrdMVPOrExperToFixToolStripMenuItem.Size = New System.Drawing.Size(575, 22)
        Me.SubmitToAMicrosoftUserGroupForAWOrdMVPOrExperToFixToolStripMenuItem.Text = "Submit to a Microsoft user group for a Word MVP or expert to fix"
        '
        'CommercialAlternativesToolStripMenuItem
        '
        Me.CommercialAlternativesToolStripMenuItem.AccessibleRole = System.Windows.Forms.AccessibleRole.ColumnHeader
        Me.CommercialAlternativesToolStripMenuItem.Name = "CommercialAlternativesToolStripMenuItem"
        Me.CommercialAlternativesToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.CommercialAlternativesToolStripMenuItem.Text = "Commercial Alternatives"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(280, 6)
        '
        'CImawareSoftwareToolStripMenuItem
        '
        Me.CImawareSoftwareToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem17, Me.OfficeFixToolStripMenuItem})
        Me.CImawareSoftwareToolStripMenuItem.Name = "CImawareSoftwareToolStripMenuItem"
        Me.CImawareSoftwareToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.CImawareSoftwareToolStripMenuItem.Text = "Try Cimaware Software"
        '
        'ToolStripMenuItem17
        '
        Me.ToolStripMenuItem17.Name = "ToolStripMenuItem17"
        Me.ToolStripMenuItem17.Size = New System.Drawing.Size(142, 22)
        Me.ToolStripMenuItem17.Text = "Try WordFix"
        '
        'OfficeFixToolStripMenuItem
        '
        Me.OfficeFixToolStripMenuItem.Name = "OfficeFixToolStripMenuItem"
        Me.OfficeFixToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.OfficeFixToolStripMenuItem.Text = "Try OfficeFix"
        '
        'TryOurManual22RepairToolStripMenuItem
        '
        Me.TryOurManual22RepairToolStripMenuItem.Name = "TryOurManual22RepairToolStripMenuItem"
        Me.TryOurManual22RepairToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.TryOurManual22RepairToolStripMenuItem.Text = "Try Our Manual $22 Repair Service"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem16, Me.AboutToolStripMenuItem, Me.ToolStripSeparator4, Me.ToolStripMenuItem6})
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(43, 22)
        Me.ToolStripMenuItem5.Text = "Help"
        '
        'ToolStripMenuItem16
        '
        Me.ToolStripMenuItem16.Name = "ToolStripMenuItem16"
        Me.ToolStripMenuItem16.Size = New System.Drawing.Size(210, 22)
        Me.ToolStripMenuItem16.Text = "Please Donate Via PayPal"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(207, 6)
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(210, 22)
        Me.ToolStripMenuItem6.Text = "Help"
        '
        'RecoverButton
        '
        Me.RecoverButton.Location = New System.Drawing.Point(385, 35)
        Me.RecoverButton.Margin = New System.Windows.Forms.Padding(2)
        Me.RecoverButton.Name = "RecoverButton"
        Me.RecoverButton.Size = New System.Drawing.Size(59, 22)
        Me.RecoverButton.TabIndex = 146
        Me.RecoverButton.Text = "Recover"
        Me.RecoverButton.UseVisualStyleBackColor = True
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.White
        Me.PictureBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox8.Image = Global.SavvyDOCXRecovery.My.Resources.Resources.tony_jolan_math_tag_tool_icon
        Me.PictureBox8.Location = New System.Drawing.Point(285, 163)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Padding = New System.Windows.Forms.Padding(3)
        Me.PictureBox8.Size = New System.Drawing.Size(67, 65)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 147
        Me.PictureBox8.TabStop = False
        Me.PictureBox8.Tag = "Open and Extract Data"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(273, 239)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(93, 26)
        Me.Label11.TabIndex = 148
        Me.Label11.Text = "Tony Jolan's Math" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Tag Order Fixer"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MyApplicationBindingSource
        '
        Me.MyApplicationBindingSource.DataSource = GetType(SavvyDOCXRecovery.My.MyApplication)
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(17, 35)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(301, 23)
        Me.ProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.ProgressBar1.TabIndex = 149
        Me.ProgressBar1.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(461, 391)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.RecoverButton)
        Me.Controls.Add(Me.menuMain)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.picWordFixLink)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form1"
        Me.Text = "Savvy DOCX Recovery"
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWordFixLink, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.menuMain.ResumeLayout(False)
        Me.menuMain.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MyApplicationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents picWordFixLink As System.Windows.Forms.PictureBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents menuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem12 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem15 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AlternativesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FreeAlternativesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PreviousVersionFileRecovererForWindowsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShadowExplorerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PreviousVersionFileRecovererToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnsavedOfficeFileRecoveryStepsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StepsToRecoverOfficeFilesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StepsToRecoverAWordFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StepsToRecoveringAnOpenOfficeFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FreewareToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents S2ServicesCorruptFileRecoveryFreewareToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetDatasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SilverCodersDocToTextToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FreeServicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TryFreeOnlineServiceUseCouponS2SERVICESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents S2ServicesFreeServiceCurrentlyUnavailableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommercialAlternativesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CImawareSoftwareToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem17 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OfficeFixToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TryOurManual22RepairToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem16 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MicrosoftsFreeOffVisMightHelpWithDOCCorruptionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UploadToZohoOfficeManyUnspecifiedAndAlsoMaybeEndTagErrrorsWillLoadInZohoWriterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MrFixitThisAppletWillFixEndTagNotMatchingErrorsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubmitToAMicrosoftUserGroupForAWOrdMVPOrExperToFixToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OfficeUpdatesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HotfixForWord2007ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HotfixForWord2010ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DownloadAndInstallTheLatestOfficeServicePackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecoverButton As System.Windows.Forms.Button
    Friend WithEvents MyApplicationBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar

End Class
